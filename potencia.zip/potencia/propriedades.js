const exercicios = {
    titulo: "Principais Propriedades de Potências",
    propriedades: [
      {
        nome: "Produto de potências de mesma base",
        regra: "a^m * a^n = a^(m+n)",
        exemplo: "2^3 * 2^4 = 2^(3+4) = 2^7 = 128"
      },
      {
        nome: "Divisão de potências de mesma base",
        regra: "a^m / a^n = a^(m-n)",
        exemplo: "5^6 / 5^2 = 5^(6-2) = 5^4 = 625"
      },
      {
        nome: "Potência de potência",
        regra: "(a^m)^n = a^(m*n)",
        exemplo: "(3^2)^3 = 3^(2*3) = 3^6 = 729"
      },
      {
        nome: "Potência de produto",
        regra: "(a*b)^n = a^n * b^n",
        exemplo: "(2*3)^2 = 2^2 * 3^2 = 4 * 9 = 36"
      },
      {
        nome: "Potência de quociente",
        regra: "(a/b)^n = a^n / b^n",
        exemplo: "(4/2)^2 = 4^2 / 2^2 = 16/4 = 4"
      },
      {
        nome: "Expoente zero",
        regra: "a^0 = 1 (a ≠ 0)",
        exemplo: "7^0 = 1"
      },
      {
        nome: "Expoente negativo",
        regra: "a^-n = 1 / a^n",
        exemplo: "2^-3 = 1 / 2^3 = 1/8"
      }
    ]
  }

exports = {exercicios}