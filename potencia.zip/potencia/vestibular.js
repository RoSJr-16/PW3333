const vestibular1 = {
    vestibular: "ENEM",
    questao: "Simplifique: 2^3 * 2^5",
    resolucao: "2^(3+5) = 2^8 = 256"
  };

const vestibular2 = {
    vestibular: "FUVEST",
    questao: "Simplifique: (3^2)^3",
    resolucao: "3^(2*3) = 3^6 = 729"
  };

const vestibular3 = {
    vestibular: "UNICAMP",
    questao: "Simplifique: 5^6 / 5^2",
    resolucao: "5^(6-2) = 5^4 = 625"
  };

const vestibular4 = {
    vestibular: "UNESP",
    questao: "Resolva: 10^-2",
    resolucao: "1 / 10^2 = 1/100 = 0.01"
  }

const vestibular5 = {
    vestibular: "UFRJ",
    questao: "Simplifique: (2*3)^2",
    resolucao: "2^2 * 3^2 = 4 * 9 = 36"
  }

exports = {vestibular1, vestibular2, vestibular3, vestibular4, vestibular5}